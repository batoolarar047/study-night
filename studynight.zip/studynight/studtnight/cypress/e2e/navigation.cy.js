describe('Navigation', () => {
  beforeEach(() => {
    cy.visit('/');
  });

  it('navigates to Card Sets', () => {
    cy.get('[data-cy="nav-card-set"]').click();
    cy.get('ul.setContainer').should('exist');
  });

  it('navigates to About', () => {
    cy.get('[data-cy="nav-about"]').click();
    cy.contains(/About Study Night/i).should('be.visible');
  });

  it('navigates to Home', () => {
    cy.get('[data-cy="nav-home"]').click();
    cy.contains(/Study Night Home|Welcome/i).should('be.visible');
  });
});
