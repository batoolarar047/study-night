describe('Forms', () => {
  beforeEach(() => {
    cy.visit('/');
    cy.get('[data-cy="nav-card-set"]').click();
    cy.get('[data-cy="toggle_form"]').click();
    cy.get('[data-cy="set_form"]').should('be.visible');
  });

  it('Create Set Form - happy path', () => {
    cy.get('[data-cy="set-title"]').type('Biology 101');
    cy.get('[data-cy="submit-set"]').click();
    cy.get('ul.setContainer', { timeout: 8000 }).should('exist');
    cy.get('ul.setContainer')
      .contains(/Biology 101/i)
      .should('exist');
  });

  it('Create Set Form - empty input shows error', () => {
    cy.get('[data-cy="set-title"]').invoke('removeAttr', 'required').clear();
    cy.get('[data-cy="submit-set"]').click();

    cy.get('.error', { timeout: 8000 })
      .should('exist')
      .and('contain', 'TITLE CANNOT BE EMPTY');
  });

  it('Add Card Form - happy path', () => {
    cy.get('[data-cy="set-title"]').type('Physics 101');
    cy.get('[data-cy="submit-set"]').click();
    cy.get('ul.setContainer')
      .contains(/Physics 101/i)
      .click();

    cy.get('[data-cy="toggle_form"]').click();
    cy.get('[data-cy="card_form"]').should('be.visible');

    cy.get('[data-cy="card-term"]').type('Velocity');
    cy.get('[data-cy="card-desc"]').type('Rate of change of position');
    cy.get('[data-cy="submit-card"]').click();

    cy.contains(/Velocity/i, { timeout: 8000 }).should('exist');
    cy.contains(/Rate of change of position/i, { timeout: 8000 }).should(
      'exist',
    );
  });

  it('Add Card Form - empty fields show error', () => {
    cy.get('[data-cy="set-title"]').type('Chemistry 101');
    cy.get('[data-cy="submit-set"]').click();
    cy.get('ul.setContainer')
      .contains(/Chemistry 101/i)
      .click();

    cy.get('[data-cy="toggle_form"]').click();
    cy.get('[data-cy="card_form"]').should('be.visible');

    cy.get('[data-cy="card-term"]').invoke('removeAttr', 'required').clear();
    cy.get('[data-cy="card-desc"]').invoke('removeAttr', 'required').clear();
    cy.get('[data-cy="submit-card"]').click();

    cy.get('.error', { timeout: 8000 })
      .should('exist')
      .and('contain', 'TERM AND DESCRIPTION CANNOT BE EMPTY');
  });
});
