import gulp from 'gulp';
import shell from 'gulp-shell';
import fs from 'fs';

const ENTRY_CANDIDATES = ['src/index.html', 'index.html', 'public/index.html'];
const ENTRY = ENTRY_CANDIDATES.find((p) => fs.existsSync(p));
if (!ENTRY) {
  console.error('❌ Could not find an HTML entry among:', ENTRY_CANDIDATES.join(', '));
  process.exit(1);
}
const QENTRY = `"${ENTRY}"`;

// Tasks
const parcelServe = shell.task([`npx parcel serve ${QENTRY} --port 1234`]);
const parcelBuild = shell.task([`npx parcel build ${QENTRY}`]);
const mochaTest   = shell.task([`npx mocha`]);
const cypressRun  = shell.task([`npx cypress run`]);

export function dev(done) {
  return parcelServe(done);
}
export function build(done) {
  return parcelBuild(done);
}
export function test(done) {
  return mochaTest(done);
}
export function e2e(done) {
  return cypressRun(done);
}

export const ci = gulp.series(build, test, e2e);
export default dev;
