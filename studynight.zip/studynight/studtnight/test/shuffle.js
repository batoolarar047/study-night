import { expect } from 'chai';
import { shuffle } from '../src/shuffle.js';

describe('shuffle', () => {
  it('reorders indices: same items, different order (probabilistic)', () => {
    const arr = Array.from({ length: 20 }, (_, i) => i);
    const copy = arr.slice();
    const out = shuffle(copy);
    // Same multiset
    expect(out.slice().sort((a,b)=>a-b)).to.deep.equal(arr);
    // Probably not identical order
    const same = out.every((v,i)=>v===arr[i]);
    expect(same).to.equal(false);
  });
});
