// Utility DOM creation helpers

/** Create a generic element with text */
const createElement = (elementType, text = '') => {
  const el = document.createElement(elementType);
  if (text != null) el.textContent = text;
  return el;
};

/** Create an <img> with src/alt */
const createImage = (src, alt = '') => {
  const img = document.createElement('img');
  img.src = src;
  img.alt = alt;
  return img;
};

/** Create a header element, e.g., ('h1', 'Title', 'my-class') */
const createHeader = (tagName, text = '', className = '') => {
  const el = document.createElement(tagName);
  if (text) el.textContent = text;
  if (className) el.className = className;
  return el;
};

/** Create a button that toggles the visibility of a target element */
const createToggleButton = (text, target) => {
  const btn = createElement('button', text);

  const show = () => {
    target.classList.remove('notVisible');
    if (!target.style.display || target.style.display === 'none') {
      target.style.display = 'block';
    }
    btn.setAttribute('aria-expanded', 'true');
  };

  const hide = () => {
    target.classList.add('notVisible');
    target.style.display = 'none';
    btn.setAttribute('aria-expanded', 'false');
  };

  btn.addEventListener('click', (e) => {
    e.preventDefault();
    const isHidden =
      target.classList.contains('notVisible') ||
      getComputedStyle(target).display === 'none';

    if (isHidden) {
      show();
    } else {
      hide();
    }
  });

  return btn;
};

/** Create a <label> with text and htmlFor */
const createLabel = (text, htmlFor) => {
  const label = document.createElement('label');
  label.textContent = text;
  if (htmlFor) label.htmlFor = htmlFor;
  return label;
};

/** Create a text <input> with id/name and common attributes */
const createInput = (id) => {
  const input = document.createElement('input');
  input.type = 'text';
  if (id) {
    input.id = id;
    input.name = id;
  }
  input.required = true;
  return input;
};

/** Create a submit <input> */
const createSubmitButton = (value = 'Submit') => {
  const submit = document.createElement('input');
  submit.type = 'submit';
  submit.value = value;
  return submit;
};

export {
  createElement,
  createImage,
  createHeader,
  createToggleButton,
  createLabel,
  createInput,
  createSubmitButton,
};
